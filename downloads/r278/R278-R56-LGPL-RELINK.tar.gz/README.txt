R278 QA: LGPL libdcadec source and relinkable decoder object.
libdcadec commit b93deed1a231dd6dd7e39b9fe7d2abe05aa00158, license in dcadec/COPYING.LGPLv2.1.
Run sh relink.sh /path/to/local/LG/sysroot/usr/lib with arm-linux-gnueabi-gcc, arm-linux-gnueabi-ar and make.
Use target runtime libraries from a compatible firmware. This kit contains no LG firmware.
The relinked plugin matches the scrubbed candidate except for the ELF build ID. Installers that pin SHA256 need a corresponding updated checksum when using a replacement.
