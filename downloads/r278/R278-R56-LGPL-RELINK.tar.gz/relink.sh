#!/bin/sh
set -eu
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P)
[ "$#" -eq 1 ] || { echo 'Usage: sh relink.sh LOCAL_LG_SYSROOT_USR_LIB' >&2; exit 2; }
lib=$(CDPATH='' cd -- "$1" && pwd -P)
make -C "$here/dcadec" -j4 CC=arm-linux-gnueabi-gcc AR=arm-linux-gnueabi-ar \
    'CFLAGS=-std=gnu99 -O2 -ffast-math -fPIC -march=armv7-a -mfpu=neon-vfpv4 -mfloat-abi=softfp -Wall -Wextra' \
    libdcadec/libdcadec.a
arm-linux-gnueabi-gcc -shared "$here/gstaleksdtsdec.o" "$here/dcadec/libdcadec/libdcadec.a" \
    -L"$lib" -Wl,--allow-shlib-undefined -Wl,--no-as-needed \
    -l:libgstaudio-1.0.so.0 -l:libgstbase-1.0.so.0 -l:libgstreamer-1.0.so.0 \
    -l:libgobject-2.0.so.0 -l:libglib-2.0.so.0 -l:libgmodule-2.0.so.0 -lm -o "$here/libgstaleksdts.so"
arm-linux-gnueabi-strip --strip-unneeded "$here/libgstaleksdts.so"
python3 - "$here/libgstaleksdts.so" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
binary = p.read_bytes()
marker = b"https://github.com/aerolit266/AlekS-DTS-webOS#____"
assert binary.count(marker + bytes(1)) == 1
p.write_bytes(binary.replace(marker, marker[:-5] + bytes(5)))
PY
sha256sum "$here/libgstaleksdts.so"
