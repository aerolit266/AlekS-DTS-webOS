#!/bin/sh
# Copyright 2026 AlekS / GameFree24 (@aerolit266)
set -eu
umask 077
export LC_ALL=C

here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P)
home=/var/lib/webosbrew
root=$home/aleks-dts-r278
config=/var/systemd/system/env/umediaserver.env
base=/usr/lib/gstreamer-1.0:/mnt/lg/res/lglib/gstreamer-1.0

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
hash() { printf '%s  %s\n' "$1" "$2" | sha256sum -c -; }

platform() {
    [ "$(id -u)" = 0 ] || fail 'Root is required.'
    [ "$(uname -m)" = armv7l ] || fail 'Expected ARMv7.'
    luna-send </dev/null -n 1 -w 2200 luna://com.webos.service.tv.systemproperty/getSystemInfo \
        '{"keys":["modelName","firmwareVersion","sdkVersion"]}' |
        python -c 'import json,sys
x=json.load(sys.stdin)
sys.exit(0 if x.get("returnValue") is True and
    (x.get("modelName"), x.get("firmwareVersion"), x.get("sdkVersion")) ==
    ("65NANO896PC", "03.60.96", "6.6.0") else 1)' || fail 'Unsupported model or firmware.'
    hash 46a353723ec66894596d9ce0822c3f2273422731ad0426fc6ff16beb349162bc /usr/sbin/umediaserver
    hash 312575ffe0995e508ce2ea315f9142ca1e5eef7fdbef378a0411aac87f9a25dc /usr/sbin/starfish-media-pipeline
    hash 794dba17945a298fffa46907743a12c0103fc71d0c5e460685ca7623b694bda2 /usr/lib/libgstreamer-1.0.so.0.1602.0
}

verify_files() {
    p=$1/plugins
    hash 5c3b798d4c1109414efc9209276dbf8b23466376f72f5bc71cf4144f3f5a1cbb "$p/libgstaleksdts.so"
    hash 1995a6b6030f6ddb895aeeea4017dcc71db8ebd6caace0107e1c5a33875f0605 "$p/libgstaleksdtscaps.so"
    hash 9b7adb2744a9d7c329669974c15bcfc86ba62daf27efccb95e362c1928d602e0 "$p/libgstaleksdtsr130optin.so"
    hash dfefb960d49d50ed7629cc4459ffaae8b420509cc9815d8337f6be7faaac18cf "$p/libgstaleksdts16dec.so"
    hash 7b49fee09f78add1fb27afd404dc7ec229f4950e5803c081e1068b6d245587ae "$1/fixtures/dts-stereo.mka"
    hash 7f9ed29c1ea9e6493d1977590a8506e432897f2eabd29ef2d7fc1ef48a4af6b5 "$1/fixtures/dts-51.mka"
    hash ab82bf91f6b61fc5a3cdf11ccd1e3bf3b4d91e2a9b7667d97f87e2cc12089a88 "$1/fixtures/ac3-51.mka"
}

verify_pipeline() (
    directory=$1
    work=$2
    mkdir -p "$work"
    mkdir -p "$work/cache"
    run_gst() {
        env -i PATH=/usr/bin:/bin:/usr/sbin:/sbin LC_ALL=C \
            XDG_CACHE_HOME="$work/cache" GST_PLUGIN_PATH_1_0="$base:$directory/plugins" \
            GST_REGISTRY_1_0="$work/combined.reg" GST_REGISTRY_UPDATE=yes \
            ALEKS_DTS_R130_ALLOW_AUTOPLUG=YES timeout -t 20 "$@"
    }
    run_gst /usr/bin/gst-inspect-1.0 aleksdtsr130optin > "$work/parser.log" 2>&1
    run_gst /usr/bin/gst-inspect-1.0 aleksdts16dec > "$work/decoder.log" 2>&1
    grep -Eq 'Rank.*\(322\)' "$work/parser.log"
    grep -Eq 'Rank.*\(288\)' "$work/decoder.log"
    check_clip() {
        clip=$1
        format=$2
        channels=$3
        mask=$4
        out=$work/$clip.log
        run_gst /usr/bin/gst-launch-1.0 -v filesrc "location=$directory/fixtures/$clip.mka" \
            '!' matroskademux name=dm dm.audio_0 '!' queue '!' decodebin '!' fakesink sync=false \
            > "$out" 2>&1 || fail "Playback check failed. See $out"
        grep -Fq 'Got EOS' "$out" || fail "Missing EOS in $out."
        caps=$(grep 'GstFakeSink:.*GstPad:sink: caps = audio/x-raw' "$out" | tail -1)
        case "$caps" in
            *"format=(string)$format"*|*"format=(string)\"$format\""*) ;;
            *) fail "Unexpected PCM format in $out." ;;
        esac
        printf '%s\n' "$caps" | grep -F "channels=(int)$channels," | grep -F 'rate=(int)48000' |
            grep -Fq "channel-mask=(bitmask)$mask" || fail "Unexpected channel layout in $out."
        if [ "$format" = S16LE ]; then
            grep -q 'AlekSDtsR130:.*GstPad:src: caps = audio/x-dts' "$out"
            grep -Fq 'AlekSDts16DecBin' "$out"
        else
            printf '%s\n' "$caps" | grep -F 'mode:passthrough' | grep -Fq 'codec_type=(string)AC3'
            if grep -Eq 'AlekSDtsR130:|AlekSDts16DecBin' "$out"; then
                fail "DTS plugin selected for AC3 in $out."
            fi
        fi
        printf 'PASS %s\n' "$clip"
    }
    check_clip dts-stereo S16LE 2 0x0000000000000003
    check_clip dts-51 S16LE 6 0x0000000000000c0f
    check_clip ac3-51 S8 1 0x0000000000000000
    test -s "$work/combined.reg"
)

before_matches() {
    if [ -f "$root/original.absent" ]; then
        [ ! -e "$config" ] && [ ! -L "$config" ]
    else
        [ ! -L "$config" ] && cmp -s "$root/original.env" "$config"
    fi
}

config_check() {
    [ -d "$(dirname "$config")" ] || fail 'Media service configuration directory is missing.'
    [ ! -L "$config" ] || fail 'Unexpected symlink at the media configuration path.'
    if [ -e "$config" ]; then
        [ -f "$config" ] && [ "$(stat -c %u:%g "$config")" = 0:0 ] || fail 'Unexpected media configuration type or owner.'
        if grep -Eq '^[[:space:]]*(GST_|ALEKS_DTS_)' "$config"; then
            fail 'Existing media plugin configuration. This installer targets an unmodified media configuration.'
        fi
    fi
}

replace_config() (
    file=$1
    tmp=$(mktemp "$config.r278.XXXXXX")
    trap 'rm -f "$tmp"' EXIT
    cp -p "$file" "$tmp"
    sync -f "$tmp"
    mv -f "$tmp" "$config"
    sync -f "$config"
    cmp -s "$file" "$config"
)

case "$*" in
    verify)
        platform
        verify_files "$here"
        scratch=$(mktemp -d /tmp/aleks-dts-r278-check.XXXXXX)
        printf 'Verification logs: %s\n' "$scratch"
        verify_pipeline "$here" "$scratch"
        exit 0
        ;;
    install|rollback) action=$1 ;;
    *) fail 'Usage: sh install.sh verify | install | rollback' ;;
esac

[ "$(id -u)" = 0 ] || fail 'Root is required.'
[ -d "$home" ] && [ ! -L "$home" ] && [ "$(stat -c %u "$home")" = 0 ] || fail 'An existing root-owned Homebrew setup is required.'
exec 9>"$home/.aleks-dts-r278.lock"
flock -x 9
[ ! -L "$root" ] || fail 'Unexpected symlink at the installation path.'
if [ -d "$root" ]; then
    [ "$(stat -c %u:%a "$root")" = 0:700 ] || fail 'Unexpected installation-directory owner or permissions.'
fi

if [ "$action" = rollback ]; then
    [ -f "$root/ready" ] || fail 'R278 recovery data was not found.'
    [ ! -L "$config" ] || fail 'Unexpected symlink at the media configuration path.'
    if cmp -s "$root/installed.env" "$config"; then
        if [ -f "$root/original.absent" ]; then
            rm "$config"
            sync -f "$(dirname "$config")"
        else
            (cd "$root" && sha256sum -c original.sha256)
            replace_config "$root/original.env"
        fi
    else
        before_matches || fail 'Media configuration changed since installation. Recovery data is still present.'
    fi
    before_matches || fail 'Rollback verification failed.'
    printf 'Rollback verified. Fully reboot the TV.\n'
    exit 0
fi

platform
verify_files "$here"
systemctl is-active --quiet umediaserver.service || fail 'Media service is not active.'
[ "$(systemctl show umediaserver.service -p DropInPaths)" = DropInPaths= ] ||
    fail 'Unexpected media-service override.'
systemctl show umediaserver.service -p EnvironmentFiles | grep -Fq "$config" ||
    fail 'The media service uses a different configuration path.'

if [ -f "$root/ready" ]; then
    (cd "$root" && sha256sum -c installed.sha256)
    if cmp -s "$root/installed.env" "$config"; then
        printf 'R278 is already configured. Reboot if the TV has not loaded it yet.\n'
        exit 0
    fi
    before_matches || fail 'Media configuration changed since preparation.'
else
    config_check
    if [ -e "$root" ]; then
        fail "Incomplete staging at $root. The existing media configuration was not replaced by this installer."
    fi
    mkdir -m 0700 "$root"
    trap 'if [ ! -f "$root/ready" ]; then rm -rf -- "$root"; fi' EXIT
    trap 'exit 1' HUP INT TERM
    mkdir "$root/plugins" "$root/fixtures"
    for f in libgstaleksdts libgstaleksdtscaps libgstaleksdtsr130optin libgstaleksdts16dec; do
        cp "$here/plugins/$f.so" "$root/plugins/"
    done
    for f in dts-stereo dts-51 ac3-51; do
        cp "$here/fixtures/$f.mka" "$root/fixtures/"
    done
    cp "$here/install.sh" "$root/install.sh"
    verify_files "$root"
    if [ -f "$config" ]; then
        cp -p "$config" "$root/original.env"
        (cd "$root" && sha256sum original.env > original.sha256)
    else
        touch "$root/original.absent"
    fi
    verify_pipeline "$root" "$root"
    {
        if [ -f "$root/original.env" ]; then cat "$root/original.env"; printf '\n'; fi
        printf 'GST_PLUGIN_PATH_1_0=%s:%s/plugins\n' "$base" "$root"
        printf 'GST_REGISTRY_1_0=%s/combined.reg\n' "$root"
        printf '%s\n' GST_REGISTRY_UPDATE=no ALEKS_DTS_R130_ALLOW_AUTOPLUG=YES
    } > "$root/installed.env"
    if [ -f "$root/original.env" ]; then
        chmod "$(stat -c %a "$root/original.env")" "$root/installed.env"
    else
        chmod 0644 "$root/installed.env"
    fi
    (cd "$root" && sha256sum installed.env combined.reg plugins/*.so > installed.sha256)
    touch "$root/ready"
    sync -f "$root"
    before_matches || fail 'Media configuration changed during preparation.'
fi
replace_config "$root/installed.env"
printf 'R278 configured. Fully reboot the TV. Rollback: sh %s/install.sh rollback\n' "$root"
